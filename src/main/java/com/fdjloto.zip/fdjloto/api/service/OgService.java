package com.fdjloto.api.service;

import com.fdjloto.api.model.Tirage;
import com.fdjloto.api.repository.TirageRepository;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

import com.fdjloto.api.exception.TirageNotFoundException;

/**
 * Service dédié à la génération des données pour les images OG (Open Graph).
 * Permet de récupérer les tirages depuis MongoDB.
 */
@Service
@Profile("!test")
public class OgService {

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE;

    private final TirageRepository tirageRepository;

    /**
     * Injection du repository MongoDB
     */
    public OgService(TirageRepository tirageRepository) {
        this.tirageRepository = tirageRepository;
    }

    /**
     * 🔍 Récupère un tirage à partir d'une date (LocalDate)
     *
     * @param date Date du tirage
     * @return Optional<Tirage>
     */
    public Optional<Tirage> getTirage(LocalDate date) {
        if (date == null) {
            return Optional.empty();
        }

        String formattedDate = date.format(FORMATTER);
        return tirageRepository.findByDateDeTirage(formattedDate);
    }

    /**
     * 🔥 Retourne le tirage ou lance une exception métier
     *
     * @param date Date du tirage
     * @return Tirage
     */
    public Tirage getTirageOrThrow(LocalDate date) {
        if (date == null) {
            throw new IllegalArgumentException("La date ne peut pas être null");
        }

        String formattedDate = date.format(FORMATTER);

        return tirageRepository.findByDateDeTirage(formattedDate)
                .orElseThrow(() ->
                        new TirageNotFoundException(
                                "Tirage introuvable pour la date : " + formattedDate
                        )
                );
    }

    /**
     * 📅 Récupère le dernier tirage disponible (utile SEO homepage)
     */
    public Optional<Tirage> getLatestTirage() {
        return tirageRepository.findFirstByOrderByDateDeTirageDesc();
    }
}
