package com.fdjloto.api.service;

import com.fdjloto.api.model.Tirage;
import com.fdjloto.api.repository.TirageRepository;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;
import java.util.Optional;

import com.fdjloto.api.exception.TirageNotFoundException;

import java.time.*;
import java.util.Date;
/**
 * Service dédié à la génération des données pour les images OG (Open Graph).
 * Permet de récupérer les tirages depuis MongoDB.
 */
@Service
public class OgService {

    private final TirageRepository tirageRepository;

    public OgService(TirageRepository tirageRepository) {
        this.tirageRepository = tirageRepository;
    }

    public Optional<Tirage> getTirage(LocalDate date) {

        if (date == null) return Optional.empty();

        String formattedDate = date.toString();

        return tirageRepository.findByDateDeTirageStartingWith(formattedDate);
    }

    public Tirage getTirageOrThrow(LocalDate date) {

        if (date == null) {
            throw new IllegalArgumentException("La date ne peut pas être null");
        }

        String formattedDate = date.toString();

        return tirageRepository.findByDateDeTirageStartingWith(formattedDate)
                .orElseThrow(() ->
                        new TirageNotFoundException(
                                "Tirage introuvable pour la date : " + formattedDate
                        )
                );
    }

    public Optional<Tirage> getLatestTirage() {
        return tirageRepository.findFirstByOrderByDateDeTirageDesc();
    }
}
